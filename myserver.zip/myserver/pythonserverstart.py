from http.server import test, SimpleHTTPRequestHandler
test(SimpleHTTPRequestHandler)